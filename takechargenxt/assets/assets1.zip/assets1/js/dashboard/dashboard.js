"use strict";
// Class definition
var KTDashboard = function() {

	// Daily Sales chart.
	// Based on Chartjs plugin - http://www.chartjs.org/
	var dailySales = function() {
		var chartContainer = KTUtil.getByID('kt_chart_daily_sales');

		if (!chartContainer) {
			return;
		}

		var chartData = {
			labels: ["Apr 05, 2019", "Apr 05, 2019", "Apr 05, 2019", "Apr 05, 2019", "Apr 13, 2019", "Apr 14, 2019", "Apr 16, 2019", "Apr 17, 2019", "Apr 18, 2019", "Apr 19, 2019", "Apr 20, 2019", "Apr 21, 2019", "Apr 22, 2019", "Apr 23, 2019", "Apr 24, 2019", "Apr 25, 2019"],
			datasets: [{
				label: 'Earning $',
				backgroundColor: KTApp.getStateColor('info'),
				data: [
					15, 20, 25, 30, 25, 20, 15, 20, 25, 30, 25, 20, 15, 10, 15, 20
				]
			}]
		};

		var chart = new Chart(chartContainer, {
			type: 'bar',
			data: chartData,
			options: {
				title: {
					display: false,
				},
				tooltips: {
					intersect: false,
					mode: 'nearest',
					xPadding: 10,
					yPadding: 10,
					caretPadding: 10
				},
				legend: {
					display: false
				},
				responsive: true,
				maintainAspectRatio: false,
				barRadius: 4,
				scales: {
					xAxes: [{
						display: false,
						gridLines: false,
						stacked: true
					}],
					yAxes: [{
						display: false,
						stacked: true,
						gridLines: false
					}]
				},
				layout: {
					padding: {
						left: 0,
						right: 0,
						top: 0,
						bottom: 0
					}
				}
			}
		});
	}

	return {
		// Init demos
		init: function() {
			// init charts
			dailySales();

			// demo loading
			var loading = new KTDialog({'type': 'loader', 'placement': 'top center', 'message': 'Loading ...'});
			loading.show();

			setTimeout(function() {
				loading.hide();
			}, 3000);
		}
	};
}();

// Class initialization on page load
jQuery(document).ready(function() {
	KTDashboard.init();
});
