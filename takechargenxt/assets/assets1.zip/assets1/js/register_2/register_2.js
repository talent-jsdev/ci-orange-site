// Class definition
var KTSelect2 = function() {
    // Private functions
    var demos = function() {
        // basic
		$("#mobilephone").inputmask("mask", {
			"mask": "(999) 999-9999"
		});
	};



    // Public functions
    return {
        init: function() {
            demos();
        }
    };
}();

// Initialization
jQuery(document).ready(function() {
    KTSelect2.init();
});
